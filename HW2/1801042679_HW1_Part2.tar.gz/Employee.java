
public class Employee {
	protected String name;
	
	public Employee(String name) {
		setName(name);
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	
	public void ChangeShipmentStatus(Shipment shipment) {
	}
	
	public void addShipment(Shipment shipment) {
	}
	
	public void DeliverShipment(Shipment shipment) {
	}
}
