
public interface CargoCompany {
	public void addBranch();
	public void removeBranch();
	public void addEmployee();
	public void removeEmployee();
	public void addShipment();
	public void ChangeShipmentStatus();
	public void markAsdelivered();
	public void ShipmentInfo();
	
	
}
