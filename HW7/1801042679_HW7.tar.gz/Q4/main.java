package softwareStore;

public class main {

	public static void main(String[] args) {
		SStore mySStore = new SStore();
		mySStore.mainMenu();

	}

}
